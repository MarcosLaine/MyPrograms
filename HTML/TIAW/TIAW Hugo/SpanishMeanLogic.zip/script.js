const carouselContainer = document.querySelector('.crypto-carousel-container');
const prevButton = document.querySelector('.crypto-carousel-prev');
const nextButton = document.querySelector('.crypto-carousel-next');

const coins = [
	{ symbol: 'BTC', price: '132.139,28' },
	{ symbol: 'ETH', price: '8.841,15' },
	{ symbol: 'BNB', price: '1.532,63' },
	{ symbol: 'ADA', price: '1,81' },
];

let currentPosition = 0;

function updateCarousel() {
	const item = carouselContainer.querySelector('.crypto-carousel-item');
	const { symbol, price } = coins[Math.abs(currentPosition) / item.offsetWidth];

	item.querySelector('h3').textContent = symbol;
	item.querySelector('p').textContent = `R$ ${price}`;
}

updateCarousel();

prevButton.addEventListener('click', () => {
	if (currentPosition === 0) {
		return;
	}
	currentPosition += carouselContainer.querySelector('.crypto-carousel-item').offsetWidth;
	carouselContainer.style.transform = `translateX(${currentPosition}px)`;
	updateCarousel();
});

nextButton.addEventListener('click', () => {
	const lastPosition = -(carouselContainer.children.length - 1) * carouselContainer.querySelector('.crypto-carousel-item').offsetWidth;
	if (currentPosition === lastPosition) {
		return;
	}
	currentPosition -= carouselContainer.querySelector('.crypto-carousel-item').offsetWidth;
	carouselContainer.style.transform = `translateX(${currentPosition}px)`;
	updateCarousel();
});
  